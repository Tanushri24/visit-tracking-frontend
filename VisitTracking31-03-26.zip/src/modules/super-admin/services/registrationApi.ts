import BaseApiService from '../../../auth/services/BaseApiService';

const api = new BaseApiService('https://localhost:7146/api');

export interface CreateEmployeeRequest {
    fullName: string;
    email: string;
    mobile: string;
    roleId: number;
    departmentId: number;
    employeeCode: string;
    designationId: number;
    reportingManagerId: number;
    locationId: number;
}


export interface ApiResponse {
    success: boolean;
    message: string;
    data?: any;
    error?: string;
    statusCode?: number;
}

export const createEmployee = async (
    employeeData: CreateEmployeeRequest
): Promise<ApiResponse> => {
    try {
        console.log("Sending request to:", "/Admin/create-employee");
        console.log("Request payload:", JSON.stringify(employeeData, null, 2));

        const response = await api.post<any>("/Admin/create-employee", employeeData);
        const responseData = response.data;
        const validationErrors = responseData?.errors;
        const validationMessage =
            validationErrors && typeof validationErrors === "object"
                ? Object.values(validationErrors).flat().join("\n")
                : null;

        if (response.status >= 200 && response.status < 300) {
            console.log("Response status:", response.status);
            console.log("Response data:", JSON.stringify(responseData, null, 2));

            return {
                success: true,
                message: responseData?.message || "Employee created successfully",
                data: responseData,
                statusCode: response.status,
            };
        }

        const errorMessage =
            validationMessage ||
            responseData?.message ||
            responseData?.title ||
            "Failed to create employee";

        return {
            success: false,
            message: errorMessage,
            error: errorMessage,
            statusCode: response.status,
        };
    } catch (error) {
        console.error("API Error:", error);
        const axiosError = error as any;
        const statusCode = axiosError?.response?.status ?? 0;
        const responseData = axiosError?.response?.data;
        const validationErrors = responseData?.errors;
        const validationMessage =
            validationErrors && typeof validationErrors === "object"
                ? Object.values(validationErrors).flat().join("\n")
                : null;
        const errorMessage =
            validationMessage ||
            responseData?.message ||
            responseData?.title ||
            axiosError?.message ||
            "Unknown error";

        return {
            success: false,
            message: errorMessage,
            error: errorMessage,
            statusCode,
        };
    }
};

export const registrationApi = {
    createEmployee,
};
